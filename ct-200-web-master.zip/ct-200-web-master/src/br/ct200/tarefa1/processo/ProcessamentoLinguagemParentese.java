package br.ct200.tarefa1.processo;

public class ProcessamentoLinguagemParentese implements ProcessamentoLinguagem {
	public String linguagem;

	public String getLinguagem() {
		return linguagem;
	}

	public void setLinguagem(String linguagem) {
		this.linguagem = linguagem;
	}
}
