package br.ct200.tarefa1.processo;

public interface ProcessamentoLinguagem {}
