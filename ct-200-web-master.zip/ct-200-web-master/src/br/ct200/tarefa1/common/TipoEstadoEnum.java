package br.ct200.tarefa1.common;

public enum TipoEstadoEnum {
	INICIAL, // se o estado � inicial
	FINAL, // se o estado � final
	COMUM; // se o estado n�o � inicial, nem final
}
