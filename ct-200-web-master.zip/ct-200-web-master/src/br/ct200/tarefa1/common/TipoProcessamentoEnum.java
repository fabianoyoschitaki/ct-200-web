package br.ct200.tarefa1.common;

public enum TipoProcessamentoEnum {
	UNIAO,
	CONCATENACAO,
	KLEENE,
	PARENTESE;
}
